data:extend(
{
  -- {
    -- type = "item-group",
    -- name = "angels-exploration",
    -- order = "n",
    -- inventory_order = "n",
    -- icon = "__angelsexploration__/graphics/technology/crawler-tech.png",
	-- icon_size = 128,
  -- },
  {
    type = "item-subgroup",
    name = "angels-exploration",
	group = "angels-enhancement",
	order = "z",
  },
}
)