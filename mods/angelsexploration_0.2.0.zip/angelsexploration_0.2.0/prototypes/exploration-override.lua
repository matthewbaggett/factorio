if data.raw["equipment-category"]["armoured-vehicle"] then
	table.insert(data.raw["equipment-grid"]["angels-heavy-tank"].equipment_categories,"tank")
	table.insert(data.raw["equipment-grid"]["angels-heavy-tank"].equipment_categories,"vehicle")
	table.insert(data.raw["equipment-grid"]["angels-heavy-tank"].equipment_categories,"armoured-vehicle")
end