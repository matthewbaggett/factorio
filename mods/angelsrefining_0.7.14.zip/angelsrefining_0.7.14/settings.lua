data:extend(
{
   {
    type = "bool-setting",
    name = "angels-enable-auto-barreling",
    setting_type = "startup",
    default_value = false,
    order = "a",
   },
}
)


