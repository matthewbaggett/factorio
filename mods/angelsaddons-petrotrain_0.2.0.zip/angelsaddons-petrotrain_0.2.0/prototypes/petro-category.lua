data:extend(
{
  {
    type = "item-subgroup",
    name = "angels-petrotrain",
	group = "angels-logistics",
	order = "za",
  },
  }
  )
