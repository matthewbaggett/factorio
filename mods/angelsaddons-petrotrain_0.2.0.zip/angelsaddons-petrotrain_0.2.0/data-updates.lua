if angelsmods.logistics then
	require("prototypes.petro-category")
	data.raw["item-with-entity-data"]["petro-locomotive-1"].subgroup = "angels-petrotrain"
end

