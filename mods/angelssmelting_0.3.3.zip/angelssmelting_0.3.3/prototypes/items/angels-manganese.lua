data:extend(
{
  {
    type = "item",
    name = "manganese-ore",
    icon = "__angelssmelting__/graphics/icons/ore-manganese.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "angels-manganese",
    order = "a",
    stack_size = 200
  },
  {
    type = "item",
    name = "processed-manganese",
    icon = "__angelssmelting__/graphics/icons/processed-manganese.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "angels-manganese",
    order = "b",
    stack_size = 200
  },
  {
    type = "item",
    name = "pellet-manganese",
    icon = "__angelssmelting__/graphics/icons/pellet-manganese.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "angels-manganese",
    order = "c",
    stack_size = 200
  },
  {
    type = "item",
    name = "solid-manganese-oxide",
    icon = "__angelssmelting__/graphics/icons/solid-manganese-oxide.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "angels-manganese",
    order = "d",
    stack_size = 200
  },
  {
    type = "item",
    name = "cathode-manganese",
    icon = "__angelssmelting__/graphics/icons/cathode-manganese.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "angels-manganese",
    order = "d",
    stack_size = 200
  },
  {
    type = "item",
    name = "ingot-manganese",
    icon = "__angelssmelting__/graphics/icons/ingot-manganese.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "angels-manganese",
    order = "e",
    stack_size = 200
  },
  {
    type = "fluid",
    name = "liquid-molten-manganese",
    icon = "__angelssmelting__/graphics/icons/molten-manganese.png",
	default_temperature = 100,
    heat_capacity = "0KJ",
    base_color = {r = 0.1, g = 0.1, b = 0.1},
    flow_color = {r = 0.1, g = 0.1, b = 0.1},
    max_temperature = 100,
	pressure_to_speed_ratio = 0.4,
    flow_to_energy_ratio = 0.59,
	auto_barrel = false
  },
  {
    type = "item",
    name = "angels-plate-manganese",
    icon = "__angelssmelting__/graphics/icons/plate-manganese.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "angels-manganese-casting",
    order = "f",
    stack_size = 200
  },
  {
    type = "item",
    name = "angels-roll-manganese",
    icon = "__angelssmelting__/graphics/icons/roll-manganese.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "angels-manganese-casting",
    order = "g",
    stack_size = 200
  },
}
)