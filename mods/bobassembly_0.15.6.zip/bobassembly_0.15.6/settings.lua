data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-assembly-electronicmachines",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-assembly-oilrefineries",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-assembly-chemicalplants",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-assembly-electrolysers",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },
  {
    type = "bool-setting",
    name = "bobmods-assembly-furnaces",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },
  {
    type = "bool-setting",
    name = "bobmods-assembly-multipurposefurnaces",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },
}
)


