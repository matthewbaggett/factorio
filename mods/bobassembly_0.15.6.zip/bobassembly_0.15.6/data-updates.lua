require("prototypes.assembly-updates")
require("prototypes.assembly-electronics-updates")
require("prototypes.oil-refinery-updates")
require("prototypes.chemical-plant-updates")
require("prototypes.electric-furnace-updates")
require("prototypes.electrolyser-updates")
require("prototypes.chemical-mixing-furnace-updates")


