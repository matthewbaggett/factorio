require("prototypes.recipe.accumulators-updates")
require("prototypes.recipe.boilers-updates")
require("prototypes.recipe.poles-updates")
require("prototypes.recipe.solar-panels-updates")
require("prototypes.recipe.steam-engines-updates")
require("prototypes.recipe.heat-exchangers-updates")
require("prototypes.recipe.steam-turbines-updates")

require("prototypes.technology.technology-updates")

